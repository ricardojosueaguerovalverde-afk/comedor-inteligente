# Diagrama y conexiones

El circuito se construye con un ESP32 DevKit, un sensor PIR HC-SR501, un servomotor y un LED con una resistencia de 220 Ω.

| Elemento | Pin del componente | Pin del ESP32 | Función |
|---|---|---|---|
| Sensor PIR | OUT | GPIO 2 | Envía HIGH cuando detecta movimiento |
| Servomotor | PWM / SIG | GPIO 13 | Recibe la señal de control de posición |
| LED | Ánodo, a través de resistencia de 220 Ω | GPIO 5 | Indica que se está dispensando alimento |
| Sensor PIR | VCC | 3V3 | Alimentación |
| Sensor PIR | GND | GND | Tierra |
| Servomotor | V+ | 3V3 en la simulación | Alimentación simulada |
| Servomotor | GND | GND | Tierra |
| LED | Cátodo | GND | Retorno a tierra |

## Secuencia de operación
1. En reposo, el servomotor mantiene la posición de 40° y el LED está apagado.
2. Al detectar movimiento, el PIR coloca su salida en HIGH.
3. Si `dispensado` es `false`, el servo gira a 140° y el LED se enciende.
4. Después de 1,5 segundos, el servo regresa a 40° y el LED se apaga.
5. `dispensado` cambia a `true` para impedir una nueva dispensación durante la misma detección.
6. Cuando el PIR vuelve a LOW, `dispensado` se restablece a `false`.

El archivo `../firmware/diagram.json` contiene el diagrama editable para Wokwi.

**Nota de montaje físico:** la alimentación de un servomotor real debe cumplir las especificaciones de su fabricante. Si se utiliza una fuente externa, las tierras (GND) deben estar conectadas en común. La conexión de alimentación mostrada en la simulación no debe asumirse automáticamente como adecuada para todo servo físico.
