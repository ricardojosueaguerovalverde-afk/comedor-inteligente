// EL-1200 Introducción a la Electrónica
// Comedero Inteligente para Gatos
// Basado en la guía del reto práctico del Ing. William Marín.

#include <ESP32Servo.h>

// Pines de entrada y salida
const int pinPIR = 2;       // Salida del sensor PIR
const int pinServo = 13;    // Señal del servomotor
const int pinLED = 5;       // LED indicador

// Objeto y posiciones del servomotor
Servo dispensador;
const int anguloDispensa = 140; // Compuerta abierta
const int anguloCerrado = 40;   // Compuerta cerrada

// Evita dispensar varias veces mientras el gato permanece presente
bool dispensado = false;

void setup() {
  Serial.begin(115200);

  pinMode(pinPIR, INPUT);
  pinMode(pinLED, OUTPUT);

  dispensador.attach(pinServo);
  dispensador.write(anguloCerrado);
  digitalWrite(pinLED, LOW);

  Serial.println("Comedero Inteligente: Modo EN ESPERA...");
}

void loop() {
  int hayGato = digitalRead(pinPIR);

  if (hayGato == HIGH) {
    // Solo dispensa si todavía no se ha servido comida en esta detección
    if (dispensado == false) {
      Serial.println(">>> ¡Gato detectado! Dispensando alimento...");

      dispensador.write(anguloDispensa);
      digitalWrite(pinLED, HIGH);

      delay(1500); // Tiempo para que caiga el alimento

      dispensador.write(anguloCerrado);
      digitalWrite(pinLED, LOW);

      dispensado = true;
      Serial.println("Dispensación completada. Servo cerrado.");

      // Pausa de seguridad indicada en la guía
      delay(10000);
    }
  } else {
    // Cuando el gato se retira, el sistema queda listo para otra detección
    if (dispensado == true) {
      dispensado = false;
      Serial.println("Sistema reiniciado. Listo para la próxima comida.");
    }

    delay(500);
  }
}
