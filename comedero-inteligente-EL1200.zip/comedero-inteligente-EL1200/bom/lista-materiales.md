# Lista de materiales (BOM)

| Cantidad | Material | Uso |
|---:|---|---|
| 1 | ESP32 DevKit | Microcontrolador que ejecuta el programa |
| 1 | Sensor PIR HC-SR501 | Detecta la presencia o movimiento del gato |
| 1 | Servomotor | Abre y cierra la compuerta del dispensador |
| 1 | LED | Indicador visual de dispensación |
| 1 | Resistencia de 220 Ω | Limita la corriente que circula por el LED |
| Según necesidad | Cables jumper | Realizan las conexiones entre los componentes |
| 1 | Protoboard (opcional) | Facilita el montaje del circuito |

**Nota:** esta lista corresponde a los componentes indicados en la guía de la Actividad 4. No incluye una estructura mecánica, depósito ni fuente externa porque no se especifican como parte del circuito de simulación.
