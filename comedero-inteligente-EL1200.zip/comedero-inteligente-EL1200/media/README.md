# Evidencias del proyecto

Guarde en esta carpeta las evidencias reales de su simulación o montaje:

- `diagrama-cableado.png`: captura donde se vean todos los componentes conectados al ESP32.
- `monitor-serial.png`: captura de los mensajes de detección, dispensación y reinicio.
- `video-demostracion.mp4`: video de demostración, si decide incluirlo en el repositorio.

No se han agregado capturas ficticias. Debe tomar las evidencias desde su propia simulación de Wokwi.
